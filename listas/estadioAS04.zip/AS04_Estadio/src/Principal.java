import java.util.Random;
import atividade.Estadio;

public class Principal {

	public static void main(String[] args) {
		Estadio estadio = new Estadio(1000);
		
		for (int i=1; i<100; i++) {
			int catraca = (new Random()).nextInt(22);
			char sexo = (new Random()).nextInt(2)==0?'M':'F';
			System.out.println("- "+ catraca +" - "+ sexo +" --> "+ estadio.getCatracas()[catraca].entrar(sexo));
			System.out.println("Homens === "+ estadio.getQtdMas());
			System.out.println("Mulheres = "+ estadio.getQtdFem());
		}
		
		
		
		
		
		
		
		

	}

}
