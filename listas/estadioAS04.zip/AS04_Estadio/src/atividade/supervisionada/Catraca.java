package atividade.supervisionada;

import atividade.Estadio;

public class Catraca {
	private Estadio estadio;
	
	public Catraca(Estadio estadio) {
		this.estadio = estadio;
	}
	
	public boolean entrar(char sexo) {
		return this.estadio.entrar(sexo);
	}

}
