package atividade;
import atividade.supervisionada.Catraca;

public class Estadio {
	private int capacidade;
	private Catraca[] catracas;
	private int qtdMas;
	private int qtdFem;
	
	public Estadio(int capacidade) {
		this.reiniciar(capacidade);
	}
	
	public boolean entrar(char sexo) {
		if (this.qtdMas+this.qtdFem >= this.capacidade) 
			return false;
		if ((sexo == 'M') && ((this.qtdMas + 1 <= this.qtdFem * 1.1) || (this.qtdMas == this.qtdFem))) {
			this.qtdMas++;
			return true;
		}
		if ((sexo == 'F') && ((this.qtdFem + 1 <= this.qtdMas * 1.1) || (this.qtdFem == this.qtdMas))) {
			this.qtdFem++;
			return true;
		}
		return false;
	}
	
	public void reiniciar(int capacidade) {
		this.capacidade = capacidade;
		this.catracas = new Catraca[22];
		for (int i=0; i<22; i++)
			this.catracas[i] = new Catraca(this);
		this.qtdMas = 0;
		this.qtdFem = 0;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}

	public int getQtdMas() {
		return qtdMas;
	}

	public int getQtdFem() {
		return qtdFem;
	}

	public Catraca[] getCatracas() {
		return catracas;
	}
	
	

}
