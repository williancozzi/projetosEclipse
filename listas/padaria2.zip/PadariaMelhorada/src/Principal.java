import br.ucb.padariamelhorada.*;

public class Principal {
	public static void main(String[] args) {
		Gerente gerente = new Gerente();
		Botijao botijao = new Botijao(30);
		Padeiro padeiro = new Padeiro("Manoel");
		Forno forno = new Forno();
		
		botijao.fornecer();
		System.out.println(botijao.getQuantidade());
		botijao = gerente.trocarBotijao(30);
		System.out.println(botijao.getQuantidade());
		forno.solicitarTroca();
		System.out.println(botijao.getQuantidade());
		
		
		
	}
}
