package br.ucb.padariamelhorada;

import java.io.Serializable;

public class Forno implements Serializable{
	private static final long serialVersionUID = 1L;
	private Botijao botijao;
	private Pao pao;
	private Gerente gerente;
	
	public Forno() {
		
	}
	
	public void assar() {

	}
	
	public void solicitarTroca() {
		if (this.botijao.getQuantidade() <= 0) {
			System.out.println("Trocar o g�s!");
		}else {
			System.out.println("Botij�o ainda tem g�s");
		}
	}
}
