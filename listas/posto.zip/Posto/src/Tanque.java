public class Tanque {
	private float qtdEtanol;
	private float qtdGasolina;
	public float capacidade;
	
	public Tanque(float qtdEtanol, float qtdGasolina) {
		this.qtdEtanol = qtdEtanol;
		this.qtdGasolina = qtdGasolina;
		this.capacidade = 20000f;
	}

	public float getQtdEtanol() {
		return qtdEtanol;
	}

	public void setQtdEtanol(float qtdEtanol) {
		this.qtdEtanol = qtdEtanol;
	}

	public float getQtdGasolina() {
		return qtdGasolina;
	}

	public void setQtdGasolina(float qtdGasolina) {
		this.qtdGasolina = qtdGasolina;
	}
	
	public void reabastecer() {
		if(this.qtdEtanol>this.qtdGasolina) {
			this.qtdEtanol = 20000;
		}else {
			this.qtdGasolina = 20000;
		}
	}
}
