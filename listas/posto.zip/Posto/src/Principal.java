import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		int continuar = 0;
		
		Scanner teclado = new Scanner(System.in);
		Posto posto = new Posto();
		Bomba bomba1 = new Bomba();
		Bomba bomba2 = new Bomba();
		Bomba bomba3 = new Bomba();
		Bomba bomba4 = new Bomba();
		Tanque tanqueEtanol = new Tanque(5000, 0);
		Tanque tanqueGasolina = new Tanque(0, 6000);
		
		do {
			System.out.println("   Gasolina: "+bomba1.getValorLitroGasolina()+"    |    Etanol: "+bomba1.getValorLitroEtanol());
			System.out.println("  =====================================");
			System.out.println("  |    1 - Abastecer   	              |");
			System.out.println("  |    2 - Reabastecer tanques        |");
			System.out.println("  |    3 - Retirar dinheiro do caixa  |");
			System.out.println("  |    4 - Trocar pre�o do litro      |");
			System.out.println("  |    5 - Informar n�vel dos tanques |");
			System.out.println("  |    6 - Informar valor do caixa    |");
			System.out.println("  |    7 - Sair                       |");
			System.out.println("  =====================================\n");
			System.out.print("-> ");
			continuar = teclado.nextInt();
			switch(continuar) {
			
			case 1:
				System.out.println("Qual bomba? (1, 2, 3 ou 4)");
				int escolhaBomba = 0;
				escolhaBomba = teclado.nextInt();
				
				if (escolhaBomba==1) {
					System.out.println("Qual combust�vel?\n1 - Gasolina \n2 - Etanol");
					int escolhaTipoCombustivel = 0;
					escolhaTipoCombustivel = teclado.nextInt();
					if(escolhaTipoCombustivel==1) {
						System.out.println("Quantos reais deseja abastecer de gasolina?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de gasolina              |");
						qtdAbastecida = (valorDesejado / bomba1.getValorLitroGasolina());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueGasolina.setQtdGasolina((tanqueGasolina.getQtdGasolina()-qtdAbastecida));
					} else if (escolhaTipoCombustivel==2) {
						System.out.println("Quantos reais deseja abastecer de etanol?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de etanol                |");
						qtdAbastecida = (valorDesejado / bomba1.getValorLitroEtanol());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueEtanol.setQtdEtanol((tanqueEtanol.getQtdEtanol()-qtdAbastecida));						
					} else {
						System.out.println("Op��o inv�lida\n");
					}
					
				}else if(escolhaBomba==2) {
					System.out.println("Qual combust�vel?\n1 - Gasolina \n2 - Etanol");
					int escolhaTipoCombustivel1 = 0;
					escolhaTipoCombustivel1 = teclado.nextInt();
					if(escolhaTipoCombustivel1==1) {
						System.out.println("Quantos reais deseja abastecer de gasolina?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de gasolina              |");
						qtdAbastecida = (valorDesejado / bomba2.getValorLitroGasolina());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueGasolina.setQtdGasolina((tanqueGasolina.getQtdGasolina()-qtdAbastecida));
					} else if (escolhaTipoCombustivel1==2) {
						System.out.println("Quantos reais deseja abastecer de etanol?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de etanol                |");
						qtdAbastecida = (valorDesejado / bomba2.getValorLitroEtanol());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueEtanol.setQtdEtanol((tanqueEtanol.getQtdEtanol()-qtdAbastecida));						
					} else {
						System.out.println("Op��o inv�lida\n");
					}
				
				}else if(escolhaBomba==3) {
					System.out.println("Qual combust�vel?\n1 - Gasolina \n2 - Etanol");
					int escolhaTipoCombustivel2 = 0;
					escolhaTipoCombustivel2 = teclado.nextInt();
					if(escolhaTipoCombustivel2==1) {
						System.out.println("Quantos reais deseja abastecer de gasolina?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de gasolina              |");
						qtdAbastecida = (valorDesejado / bomba3.getValorLitroGasolina());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueGasolina.setQtdGasolina((tanqueGasolina.getQtdGasolina()-qtdAbastecida));
					} else if (escolhaTipoCombustivel2==2) {
						System.out.println("Quantos reais deseja abastecer de etanol?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de etanol                |");
						qtdAbastecida = (valorDesejado / bomba3.getValorLitroEtanol());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueEtanol.setQtdEtanol((tanqueEtanol.getQtdEtanol()-qtdAbastecida));						
					} else {
						System.out.println("Op��o inv�lida\n");
					}
					
				}else if(escolhaBomba==4) {
					System.out.println("Qual combust�vel?\n1 - Gasolina \n2 - Etanol");
					int escolhaTipoCombustivel3 = 0;
					escolhaTipoCombustivel3 = teclado.nextInt();
					if(escolhaTipoCombustivel3==1) {
						System.out.println("Quantos reais deseja abastecer de gasolina?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de gasolina              |");
						qtdAbastecida = (valorDesejado / bomba4.getValorLitroGasolina());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueGasolina.setQtdGasolina((tanqueGasolina.getQtdGasolina()-qtdAbastecida));
					} else if (escolhaTipoCombustivel3==2) {
						System.out.println("Quantos reais deseja abastecer de etanol?");
						float valorDesejado = 0;
						float qtdAbastecida = 0;
						valorDesejado = teclado.nextFloat();
						System.out.println("===============================================");
						System.out.println("|  Abastecido R$"+valorDesejado +" de etanol                |");
						qtdAbastecida = (valorDesejado / bomba4.getValorLitroEtanol());
						System.out.println("|  Total de litros abastecidos: "+qtdAbastecida+"     |");
						System.out.println("===============================================\n");
						posto.setValorCaixa((posto.getValorCaixa()+valorDesejado));
						tanqueEtanol.setQtdEtanol((tanqueEtanol.getQtdEtanol()-qtdAbastecida));						
					} else {
						System.out.println("Op��o inv�lida\n");
					}
				} else {
					System.out.println("Opc�o inv�lida\n");
				}
				break;
			case 2:
				tanqueEtanol.reabastecer();
				tanqueGasolina.reabastecer();
				System.out.println("\nTanques reabastecidos!\n");
				break;
				
			case 3:
				System.out.println("\nQuantos reais voc� quer retirar?");
				double valorRetirar = 0;
				valorRetirar = teclado.nextDouble();
				posto.setValorCaixa((posto.getValorCaixa()-valorRetirar));
				break;
				
			case 4:
				System.out.println("Qual o novo pre�o da gasolina?");
				float novoValorGasolina = 0;
				novoValorGasolina = teclado.nextFloat();
				bomba1.setValorLitroGasolina(novoValorGasolina);
				bomba2.setValorLitroGasolina(novoValorGasolina);
				bomba3.setValorLitroGasolina(novoValorGasolina);
				bomba4.setValorLitroGasolina(novoValorGasolina);
				System.out.println("\nQual o novo pre�o do etanol?");
				float novoValorEtanol = 0;
				novoValorEtanol = teclado.nextFloat();
				bomba1.setValorLitroEtanol(novoValorEtanol);
				bomba2.setValorLitroEtanol(novoValorEtanol);
				bomba3.setValorLitroEtanol(novoValorEtanol);
				bomba4.setValorLitroEtanol(novoValorEtanol);
				break;
				
			case 5:
				System.out.println("\nQuantidade de etanol no tanque 1: "+ tanqueEtanol.getQtdEtanol() +" litros");
				System.out.println("Quantidade de gasolina no tanque 2: "+ tanqueGasolina.getQtdGasolina() +" litros\n");
				break;
				
			case 6:
				System.out.println("\nValor em caixa: R$"+ posto.getValorCaixa()+ "\n");
				break;
				
			case 7:
				System.exit(0);;
				
			default:
				System.out.println("Op��o inv�lida");
				break;
			}
		} while (continuar!=7);
		

	}

}
