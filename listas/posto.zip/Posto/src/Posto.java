public class Posto {
	private double valorCaixa;

	public Posto() {
		this.valorCaixa = 100;
	}

	public void realizarAbastecimento() {
		
	}
		
	public void retirarDinheiroCaixa() {
		
	}

	public double getValorCaixa() {
		return this.valorCaixa;
	}

	public void setValorCaixa(double valorCaixa) {
		this.valorCaixa = valorCaixa;
	}
	
	
}
