public class Bomba {
	private float valorLitroGasolina;
	private float valorLitroEtanol;
		
	public Bomba() {
		this.valorLitroGasolina = 4.59f;
		this.valorLitroEtanol = 3.29f;
	}

	public float getValorLitroGasolina() {
		return valorLitroGasolina;
	}

	public void setValorLitroGasolina(float valorLitroGasolina) {
		this.valorLitroGasolina = valorLitroGasolina;
	}

	public float getValorLitroEtanol() {
		return valorLitroEtanol;
	}

	public void setValorLitroEtanol(float valorLitroEtanol) {
		this.valorLitroEtanol = valorLitroEtanol;
	}
	
}
