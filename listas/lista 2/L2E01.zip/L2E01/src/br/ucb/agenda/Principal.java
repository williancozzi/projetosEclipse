package br.ucb.agenda;

import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Agenda agenda = new Agenda();
		
		System.out.print("Nome: ");
		String nome = teclado.next();
		System.out.print("Telefone: ");
		String telefone = teclado.next();
		
		Contato contato1 = new Contato();
		agenda.addContato(nome, telefone);
		contato1.setNome(nome);
		contato1.setTelefone(telefone);
		
		
		System.out.println("Nome: "+contato1.getNome());
		System.out.println("Telefone: "+contato1.getTelefone());
	}
}
