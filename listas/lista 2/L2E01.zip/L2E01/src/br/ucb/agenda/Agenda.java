package br.ucb.agenda;

public class Agenda {
	private Contato contato;

	public Agenda() {
	
	}
	
	public boolean addContato(String nome, String telefone) {
		contato.setNome(nome);
		contato.setTelefone(telefone);
		return true;
	}


}
