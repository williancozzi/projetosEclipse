package br.ucb.agenda;

public class Telefone {

}
