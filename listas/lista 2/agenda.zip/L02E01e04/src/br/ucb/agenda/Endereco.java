package br.ucb.agenda;

public class Endereco {

}
