package br.ucb.escola;

public interface Usuario {
	public boolean logar(String senha);
	public String getLogin();
}
