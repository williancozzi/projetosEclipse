package com.aula11;
public class Visitante extends Pessoa {

}
