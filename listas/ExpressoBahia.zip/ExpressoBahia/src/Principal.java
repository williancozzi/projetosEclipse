import br.ucb.expressobahia.*;

public class Principal {
	public static void main(String args[]) {
		(new janelaPrincipal()).show();
	}
}
