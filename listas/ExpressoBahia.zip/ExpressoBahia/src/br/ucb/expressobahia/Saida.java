package br.ucb.expressobahia;

import java.sql.Date;

public class Saida {

	private Date horario;
	private float valor;
	private int qtdLugaresTotal;
	private int qtdLugaresVendidos;
}
